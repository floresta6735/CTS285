#Dataman Sprint 1


def main():
  print("Hello little one! I am Dataman and I am here to fuel you with knowledge! I have an assortment of buttons waiting to be pressed that lead you to extraordinary places to enlarge that brain of yours! Right now I am only holding one working button right now called the Answer Checker!")
  print("------------------------------------------------------------------------")
  print("The Answer Checker is a tool used for your brain to answer calculations that you input yourself! First submit the first number and then submit the second number! And then submit what operation you would like to use!")

main()
def AnswerChecker():
  userNum1 = int(float(input("Enter first number: ")))
  userNum2 = int(float(input("Enter second number: ")))
  userOperation = int(input("Add the operation you would like to use (1 for add, 2, for subtract, 3 for multiply, 4 for divide): "))
  if userOperation == 1:
    answer = int(float(input("What is {} + {} = ? ".format(userNum1, userNum2))))
    correctAnswer = userNum1 + userNum2
    if answer == correctAnswer:
     print("Yay!")
    else:
     print("EEE")
     
  elif  userOperation == 2:
   answer = int(float(input("What is {} - {} = ? ".format(userNum1, userNum2))))
   correctAnswer = userNum1 - userNum2
   if answer == correctAnswer:
     print("Yay!")
   else:
     print("EEE")
  elif  userOperation == 3:
   answer = int(float(input("What is {} * {} = ? ".format(userNum1, userNum2))))
   correctAnswer = userNum1 * userNum2
   if answer == correctAnswer:
     print("Yay!")
   else:
     print("EEE")
  elif  userOperation == 4:
   answer = int(float(input("What is {} / {} = ? ".format(userNum1, userNum2))))
   correctAnswer = userNum1 / userNum2
   if answer == correctAnswer:
     print("Yay!")
   else:
     print("EEE") 
       
AnswerChecker()
