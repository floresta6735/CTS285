//Main Project
//Alina Florestal
//11/15/2021
//M4Hw2



#include <iostream>
using namespace std;


void start_game();
void act_one();
void armorer();
void armorer_shop();
void beggar();
void fight_test();
void right_turn();
void intersection();
void food_shop();
void food_shop_inventory();
void armor_shop();
void armor_inventory();
void secret();
string sword;
string food;
string armor;
int score = 0;
int scoreTotal = score;
int Winpoints = 1500;
int MoneyLeft = 3000;

//main into to story, need to add tutorial 
int main(){
  cout << "Welcome to the adventure text simulator : To Save The Princess!" << endl;
  cout << "_______________________________________________________________" << endl;
  cout << "The story follows you the hero, on a long journey to save the princess Shittake from the evil witch Portobello who lives in a dark tower deep within a tricky forest. Do you think you can save the girl?" << endl;
  cout << "_________________________________________________________________" << endl;
  char start;
  cout << "Enter Y to start or N to quit" << endl;
  cin >> start;
   if (start == 'y' || start == 'Y'){
     start_game();
   }
   else{
     cout << "Goodbye" << endl;
   }
  


}
// intro to first scene
void start_game(){
  cout << "\"Wake up young hero!\"" << endl;
  cout << "You awaken to the....MUSHROOM KING?!?!?" << endl;
  cout << "\"The princess has been kidnapped!\" cries the king" << endl;
  cout << "_____________________________________________________" << endl;
  cout << "Each option you choose throughout the game through dialogue or action adds to the total score needed to save the princess(3000)" << endl;
  cout << "___________________________________________" << endl;
  cout << "Choose what you think is the best option" << endl;
  char choice;
  cout << "(a)What are you doing in my house?" << endl;
  cout << "(b)Oh no, where has she been taken?" << endl;
  cin >> choice;
   if (choice == 'a' || choice == 'A'){
     score = score - 100;
     scoreTotal = score;
     cout << "\"Is that how you talk to your king?\"" << endl;
     cout << "Total points:" << scoreTotal << endl;
     act_one();
   }
   else if (choice == 'b' || choice == 'B'){
    score = score + 100;
    scoreTotal = score;
    cout << "\"She's been taken to Death Cap Forest.\"" << endl;
    cout << "Total points:" << scoreTotal << endl;
    act_one();
   }
  }
//test of choice for ending
void act_one(){
  cout << "The king grabs you out of your house and straps you to one of his horses as you both head to the Mushroom Kingdom" << endl;
  cout << "You think in the back of your mind, \"I'm coming my lady\"" << endl;
  cout << "Welcome back hero!" << endl;
  cout << "The people of the town share faces of joy to see you.... well most of them" << endl;
  cout << "Armor here! Get your armor to fight the demons in thr forest!" <<endl;
  cout << "You think about the money the king gave you to start your journey(3000)" << endl;
  cout << "~~~~~~~~~~~~~~~~~~~~~" << endl;
  char choice;
  cout << "(a)Check the what the armorer has in stock" << endl;
  cout << "(b)Continue on your journey" << endl;
  cin >> choice;
   if (choice == 'a' || choice == 'A'){
    armorer();
   }
   else if (choice == 'b' || choice == 'B'){
     scoreTotal = score;
     cout << "Score: " << scoreTotal << endl;
     food_shop();
   }
   


}
void armorer(){
  cout << "You walk over to the blacksmith. He is a very large man, with scruffy beard, and a stern demeanor" << endl;
  cout << "\"Welcome young adventurer, I am Porto, come to look at my wares have you?\" said the blacksmith" << endl;
  cout << "~~~~~~~~~~~~~~~~~~~~~~~~~~~" << endl;
  char choice;
  cout << "(a)Yes I have." << endl;
  cout << "(b)No, nevermind." << endl;
  cin >> choice;
   if (choice == 'a' || choice == 'A'){
    armorer_shop();
   }
   else if (choice == 'b' || choice == 'B'){
     scoreTotal = score;
     cout << "Score: " << scoreTotal << endl;
     food_shop();
   } 
}
void armorer_shop(){
     cout << "You have " << MoneyLeft << " to spend." <<endl;
     char choice;
     cout << "(a)Celery Sword(500 coins)" << endl; 
     cout <<"(b)Carrot Dagger(200 coins)" << endl; 
     cout << "(c)Corn-scale bow(300 coins)" << endl;
     cout << "(d)Rock(100 coins)" << endl;
     cin >> choice;
     if (choice == 'a' || choice == 'A'){
     sword = "Celery Sword";
     MoneyLeft = MoneyLeft - 500;
     cout << "Money Left:" << MoneyLeft << endl;
     score = score + 200;
     scoreTotal = score;
     cout << "Score: " << scoreTotal << endl;
     food_shop();
     }
     else if (choice == 'b' || choice == 'B'){
       sword = "Carrot Dagger";
       MoneyLeft = MoneyLeft - 200;
       cout << "Money Left:" << MoneyLeft << endl;
       score = score + 150;
       scoreTotal = score;
       cout << "Score: " << scoreTotal << endl;
       food_shop();

     }
     else if (choice == 'c' || choice == 'c'){
       sword = "Corn-scale Bow";
       MoneyLeft = MoneyLeft - 300;
       cout << "Money Left:" << MoneyLeft << endl;
       score = score + 350;
       scoreTotal = score;
       cout << "Score: " << scoreTotal << endl;
       food_shop();
     }
     else if (choice == 'd' || choice == 'D'){
       sword = "Rock";
       MoneyLeft = MoneyLeft - 100;
       cout << "Money Left:" << MoneyLeft << endl;
       score = score + 50;
       scoreTotal = score;
       cout << "Score: " << scoreTotal << endl;
       food_shop();
     }

}
void food_shop(){
  cout << "In need of potions or food to help along the journey? Come on in to Shittake Shop to get health upgrades and more! Limit one per customer! " << endl;
  cout << " Come into the shop?(y/n)" << endl;
  char choice;
  cin >> choice;
  if (choice == 'y' || choice == 'Y'){
    food_shop_inventory();
  }
  if (choice == 'n' || choice == 'N'){
    armor_shop();
  }
}
void food_shop_inventory(){
  cout << "You have " << MoneyLeft << " to spend." <<endl;
  char choice;
     cout << "(a)Savory Soup(150 coins)" << endl; 
     cout <<"(b)Roasted Red Potion(170 coins)" << endl; 
     cout << "(c)Onion White Potion(350 coins)" << endl;
     cout << "(d)Ginger Soup(200 coins)" << endl;
     cin >> choice;
     if (choice == 'a' || choice == 'A'){
     armor = "Savory Soup";
     MoneyLeft = MoneyLeft - 150;
     cout << "Money Left:" << MoneyLeft << endl;
     score = score + 250;
     scoreTotal = score;
     cout << "Score: " << scoreTotal << endl;
     armor_shop();
     }
     else if (choice == 'b' || choice == 'B'){
       food = "Roasted Red Potion";
       MoneyLeft = MoneyLeft - 170;
       cout << "Money Left:" << MoneyLeft << endl;
       score = score + 275;
       scoreTotal = score;
       cout << "Score: " << scoreTotal << endl;
       armor_shop();

     }
     else if (choice == 'c' || choice == 'c'){
       food = "Onion White Potion";
       MoneyLeft = MoneyLeft - 350;
       cout << "Money Left:" << MoneyLeft << endl;
       score = score + 400;
       scoreTotal = score;
       cout << "Score: " << scoreTotal << endl;
       armor_shop();
     }
     else if (choice == 'd' || choice == 'D'){
       food = "Ginger Soup";
       MoneyLeft = MoneyLeft - 200;
       cout << "Money Left:" << MoneyLeft << endl;
       score = score + 275;
       scoreTotal = score;
       cout << "Score: " << scoreTotal << endl;
       armor_shop();
     }
}
void armor_shop(){
  cout << "Tring to stay protected in battle? Come visit my armory for armor that best suits your needs and limit one per customer!" << endl;
  cout << " Come into the shop?(y/n)" << endl;
  char choice;
  cin >> choice;
  if (choice == 'y' || choice == 'Y'){
    armor_inventory();
  }
  if (choice == 'n' || choice == 'N'){
    beggar();
  }
}
void armor_inventory(){
    cout << "You have " << MoneyLeft << " to spend." <<endl;
  char choice;
     cout << "(a)Golden Mushroom Armor(500 coins)" << endl; 
     cout <<"(b)Raw Onion Armor(250 coins)" << endl; 
     cout << "(c)Spiced Egg Armor(375 coins)" << endl;
     cout << "(d)Beanstalk Armor(50 coins)" << endl;
     cin >> choice;
     if (choice == 'a' || choice == 'A'){
     armor = "Golden Mushroom Armor";
     MoneyLeft = MoneyLeft - 500;
     cout << "Money Left:" << MoneyLeft << endl;
     score = score + 700;
     scoreTotal = score;
     cout << "Score: " << scoreTotal << endl;
      beggar();
     }
     else if (choice == 'b' || choice == 'B'){
       armor = "Raw Onion Armor";
       MoneyLeft = MoneyLeft - 250;
       cout << "Money Left:" << MoneyLeft << endl;
       score = score + 325;
       scoreTotal = score;
       cout << "Score: " << scoreTotal << endl;
        beggar();

     }
     else if (choice == 'c' || choice == 'c'){
       armor = "Spiced Egg Armor";
       MoneyLeft = MoneyLeft - 375;
       cout << "Money Left:" << MoneyLeft << endl;
       score = score + 450;
       scoreTotal = score;
       cout << "Score: " << scoreTotal << endl;
        beggar();
     }
     else if (choice == 'd' || choice == 'D'){
       armor = "Beanstalk Armor";
       MoneyLeft = MoneyLeft - 50;
       cout << "Money Left:" << MoneyLeft << endl;
       score = score + 100;
       scoreTotal = score;
       cout << "Score: " << scoreTotal << endl;
        beggar();
     }
}
void beggar(){
  cout << "You continue through the kingdom, and you see a young woman covered in dirt and grime, looking for anyone to pay penance" << endl;
  cout << "\"Please someone spare me some coin, I am so hungry and cold\"" << endl;
  cout << "You ponder if giving some coin to the woman is a good idea(a) or not(b)" << endl;
  cout << "You have " << MoneyLeft << " to spend." <<endl;
  char choice;
  cin >> choice;
  if (choice == 'a' || choice == 'A'){
    MoneyLeft = MoneyLeft - 200;
    score = score + 150;
    scoreTotal = score;
    cout << "Money Left:" << MoneyLeft << endl;
    cout << "Score: " << scoreTotal << endl;
    intersection();

  }
  else if (choice == 'b' || choice == 'B'){
    MoneyLeft = MoneyLeft;
    score = score;
    scoreTotal = score;
    cout << "Money Left:" << MoneyLeft << endl;
    cout << "Score: " << scoreTotal << endl;
    intersection();

  }
  else if (choice == 'm'){
    secret();
  }
}
void secret(){
  cout << "You are whisked away by the beggar to a different land, forgetting all about the rich entitled princess. The kingdom staggers and crumbles before the witch, no hero to save them, but you don't care do you?";
}
void intersection(){
  cout << "You come across an intersection, on facing the left and one facing the right.";
  cout << "You look at the right sign is covered in green moss faintly showing the letter\"D\"" << endl;
  cout << "You look to the left and see the left sign is covered in daisies and clearly reads\"Tremella Track\"" << endl;
  cout << "You think to yourself, should I take the right(R) path or the left path(L)?" << endl;
  char choice;
  cin >> choice;
  if (choice == 'r' || choice == 'R'){
    cout << "There are big patches of green moss everywhere, you cut through the forest with your" << sword << endl;
    score = score + 500;
    scoreTotal = score;
    cout << "Score: " << scoreTotal << endl;
    right_turn();
  }
  else if (choice == 'l' || choice == 'L'){
    cout << "You traverse through the track and find yourself lost, constantly looping around the tree you saw when you first entered the path. You walk for 20 years till your legs can go no longer and die covered in mushrooms, and holding your " << sword << endl;
  }
 
}
void right_turn(){
  cout << "You make it through the green moss forest to see a tall tower with white brick leading with a red spotted roof." << endl;
  cout << "You hear a woman screaming at the top and the snickering of an older woman" << endl;
  cout << "You make your way towards the tower." << endl;
  cout << "You think to yourself, should I climb the tower(a) or should I leave(b)?" << endl;
  char choice;
  cin >> choice;
  if (choice == 'a' || choice == 'A'){
    score = score + 100;
    scoreTotal = score;
    cout << "Score: " << scoreTotal << endl;
    fight_test();
  }
  else if (choice == 'b' || choice == 'B'){
    cout << "You walk back, realizing the adventure was not worth your time. You are exiled from the kingdom for not returning the princess. The End" << endl;
  }
}
//straight death test or win (lowered winpoint for test)
void fight_test(){
  if (score == Winpoints || score > Winpoints){
    cout << "You have saved the princess! Using your " << sword << "You attack the witch,she strikes you back, you devour your " << food << " and become stronger, luckily you were wearing you " << armor << " .She says to you Thank you adventurer for saving me, i am forever in your debt. You are rewarded with stacks of gold mushrooms and a shiny new sword to help with your next adventure. The End." << endl;
  }
  else if (score != Winpoints){
    cout << "You have died due to not being strong enough to fight the witch." << endl;
  }
}