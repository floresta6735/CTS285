#M1HW
#Calculation Program
#Alina Florestal
#8/19/2021


#Menu Options
def Menu():      
 print('Welcome to The Calculator Program')
 print('1. Add')
 print('2. Subtract')
 print('3. Divide ')
 print('4. Multiply')
 print('5. Exit')
 number = int(input("Enter a number: "))
 if number == 1:
  Add()
 elif number == 2:
   Subtract() 
 elif number == 3:
   Divide() 
 elif number == 4:
   Multiply()
 elif number == 5:
  print("Goodbye")   

#Function for Adding
def Add():
  print("Add")
  num1 = int(input("Enter a number: "))
  num2 = int(input("Enter a Number: "))
  Total = num1 + num2
  print(num1, "+" , num2,  "=" , Total)
  print("1. Repeat")
  print("2. Main menu")
  returnNum = int(input("Enter a Number: "))
  if returnNum == 1:
    return Add()
  else:
    return Menu()

#Function for Subtracting

def Subtract():
 print("Subtract")
 num1 = int(input("Enter a number: "))
 num2 = int(input("Enter a Number: "))
 Total = num1 - num2
 print(num1, "-" , num2,  "=" , Total)
 print("1. Repeat")
 print("2. Main menu")
 returnNum = int(input("Enter a Number: "))
 if returnNum == 1:
   return Subtract()
 else:
   return Menu()

#Function for Dividing

def Divide():
  print("Divide")
  num1 = int(input("Enter a number: "))
  num2 = int(input("Enter a Number: "))
  Total = num1 / num2
  print(num1, "/" , num2,  "=" , Total)
  print("1. Repeat")
  print("2. Main menu")
  returnNum = int(input("Enter a Number: "))
  if returnNum == 1:
   return Divide()
  else:
   return Menu()

#Function for Multiplying

def Multiply():
  print("Multiply")
  num1 = int(input("Enter a number: "))
  num2 = int(input("Enter a Number: "))
  Total = num1 * num2
  print(num1, "*" , num2,  "=" , Total)
  print("1. Repeat")
  print("2. Main menu")
  returnNum = int(input("Enter a Number: "))
  if returnNum == 1:
   return Multiply()
  else:
   return Menu()

#Function for Main menu
def main():
  Menu()
main()      